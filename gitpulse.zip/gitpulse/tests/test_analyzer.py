import json
import subprocess

import pytest

from gitpulse.analyzer import (
    GitError,
    bus_factor,
    contributors,
    heatmap,
    hotspots,
    parse_log,
    read_log,
    summary,
)
from gitpulse.cli import main

RS, FS = "\x1e", "\x1f"
SAMPLE = (
    f"{RS}aaa{FS}Alice{FS}a@x.io{FS}2024-03-04T10:15:00+00:00{FS}init\n"
    "10\t0\tapp.py\n5\t0\tREADME.md\n"
    f"{RS}bbb{FS}Alice{FS}a@x.io{FS}2024-03-05T22:00:00+00:00{FS}feat\n"
    "3\t1\tapp.py\n-\t-\tlogo.png\n"
    f"{RS}ccc{FS}Bob{FS}b@x.io{FS}2024-03-09T09:00:00+00:00{FS}fix\n"
    "1\t1\tapp.py\n"
)


def test_parse_log():
    commits = parse_log(SAMPLE)
    assert [c.sha for c in commits] == ["aaa", "bbb", "ccc"]
    assert commits[0].lines_changed == 15
    assert commits[1].changes[1].added == 0  # binary file


def test_contributors_and_bus_factor():
    commits = parse_log(SAMPLE)
    assert contributors(commits)[0][:2] == ("Alice", 2)
    assert bus_factor(commits) == 1
    assert bus_factor([]) == 0


def test_hotspots():
    top = hotspots(parse_log(SAMPLE), top=1)
    assert top == [("app.py", 3, 16)]


def test_heatmap():
    grid = heatmap(parse_log(SAMPLE))
    assert grid[0][10] == 1  # Monday 10:00
    assert sum(map(sum, grid)) == 3


def test_summary_empty():
    assert summary([])["commits"] == 0


@pytest.fixture
def repo(tmp_path):
    def git(*a):
        subprocess.run(["git", "-C", str(tmp_path), *a], check=True, capture_output=True)
    git("init", "-q")
    git("config", "user.email", "t@t.io")
    git("config", "user.name", "Tester")
    (tmp_path / "f.txt").write_text("hello\n")
    git("add", ".")
    git("commit", "-q", "-m", "first")
    return tmp_path


def test_real_repo_and_cli(repo, capsys):
    commits = parse_log(read_log(str(repo)))
    assert len(commits) == 1
    assert main([str(repo), "-f", "json"]) == 0
    data = json.loads(capsys.readouterr().out)
    assert data["summary"]["commits"] == 1


def test_not_a_repo(tmp_path, capsys):
    with pytest.raises(GitError):
        read_log(str(tmp_path))
    assert main([str(tmp_path)]) == 1
