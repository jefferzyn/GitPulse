"""Rendering analysis results as text, Markdown or JSON."""

from __future__ import annotations

import json

from gitpulse.analyzer import bus_factor, contributors, heatmap, hotspots, summary  # noqa: F401

DAYS = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
SHADES = " ░▒▓█"


def render_heatmap(grid: list) -> str:
    peak = max((v for row in grid for v in row), default=0)
    header = "     " + "".join(f"{h:<4}" if h % 2 == 0 else "" for h in range(24))
    lines = [header.rstrip()]
    for day, row in zip(DAYS, grid):
        cells = ""
        for v in row:
            idx = 0 if peak == 0 or v == 0 else max(1, round(v / peak * (len(SHADES) - 1)))
            cells += SHADES[idx] * 2
        lines.append(f"{day}  {cells}")
    return "\n".join(lines)


def build_report(commits: list, top: int = 10) -> dict:
    return {
        "summary": summary(commits),
        "contributors": [
            {"author": a, "commits": n, "lines_changed": n_lines}
            for a, n, n_lines in contributors(commits)[:top]
        ],
        "hotspots": [
            {"path": p, "commits": n, "lines_changed": n_lines}
            for p, n, n_lines in hotspots(commits, top)
        ],
        "heatmap": heatmap(commits),
    }


def render_json(commits: list, top: int = 10) -> str:
    return json.dumps(build_report(commits, top), indent=2)


def render_text(commits: list, top: int = 10, markdown: bool = False) -> str:
    r = build_report(commits, top)
    s = r["summary"]

    def h(title: str) -> str:
        return f"## {title}" if markdown else f"{title}\n{'-' * len(title)}"

    out = ["# GitPulse report" if markdown else "GitPulse report\n==============="]
    if s["commits"] == 0:
        return "\n".join(out + ["", "No commits found."])
    out += [
        "",
        h("Summary"),
        f"Commits:       {s['commits']}",
        f"Authors:       {s['authors']}",
        f"Active:        {s['first']} -> {s['last']}",
        f"Lines:         +{s['lines_added']} / -{s['lines_deleted']}",
        f"Bus factor:    {s['bus_factor']}",
        "",
        h("Top contributors"),
    ]
    out += [
        f"{i}. {c['author']}: {c['commits']} commits, {c['lines_changed']} lines"
        for i, c in enumerate(r["contributors"], 1)
    ]
    out += ["", h("Hotspots (most frequently changed files)")]
    out += [
        f"{i}. {x['path']}: {x['commits']} commits, {x['lines_changed']} lines"
        for i, x in enumerate(r["hotspots"], 1)
    ]
    block = render_heatmap(r["heatmap"])
    out += ["", h("Activity heatmap (weekday x hour)")]
    out.append("```\n" + block + "\n```" if markdown else block)
    return "\n".join(out)
