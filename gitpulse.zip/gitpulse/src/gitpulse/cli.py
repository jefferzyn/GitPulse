"""Command-line interface."""

from __future__ import annotations

import argparse
import sys
from typing import Optional, Sequence

from gitpulse import __version__
from gitpulse.analyzer import GitError, parse_log, read_log
from gitpulse.report import render_json, render_text


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="gitpulse",
        description="Analyze a git repository's history.",
    )
    p.add_argument("path", nargs="?", default=".", help="path to the repository (default: .)")
    p.add_argument("-n", "--top", type=int, default=10, help="rows per ranking (default: 10)")
    p.add_argument("-f", "--format", choices=["text", "markdown", "json"], default="text")
    p.add_argument("--since", help='only include commits since a date, e.g. "6 months ago"')
    p.add_argument("-V", "--version", action="version", version=f"%(prog)s {__version__}")
    return p


def main(argv: Optional[Sequence[str]] = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        commits = parse_log(read_log(args.path, args.since))
    except GitError as exc:
        print(f"gitpulse: error: {exc}", file=sys.stderr)
        return 1
    if args.format == "json":
        print(render_json(commits, args.top))
    else:
        print(render_text(commits, args.top, markdown=args.format == "markdown"))
    return 0
