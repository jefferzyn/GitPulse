"""Parsing git history and computing repository metrics."""

from __future__ import annotations

import subprocess
from collections import Counter, defaultdict
from dataclasses import dataclass, field
from datetime import datetime
from typing import Iterable, Optional

RECORD_SEP = "\x1e"
FIELD_SEP = "\x1f"
LOG_FORMAT = f"{RECORD_SEP}%H{FIELD_SEP}%an{FIELD_SEP}%ae{FIELD_SEP}%aI{FIELD_SEP}%s"


class GitError(RuntimeError):
    """Raised when git cannot be run or the path is not a repository."""


@dataclass
class FileChange:
    path: str
    added: int
    deleted: int


@dataclass
class Commit:
    sha: str
    author: str
    email: str
    date: datetime
    subject: str
    changes: list = field(default_factory=list)

    @property
    def lines_changed(self) -> int:
        return sum(c.added + c.deleted for c in self.changes)


def read_log(repo: str = ".", since: Optional[str] = None) -> str:
    """Return raw `git log --numstat` output for a repository."""
    cmd = ["git", "-C", repo, "log", "--numstat", f"--pretty=format:{LOG_FORMAT}"]
    if since:
        cmd.append(f"--since={since}")
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, check=True)
    except FileNotFoundError as exc:
        raise GitError("git executable not found on PATH") from exc
    except subprocess.CalledProcessError as exc:
        raise GitError(exc.stderr.strip() or "not a git repository") from exc
    return result.stdout


def parse_log(raw: str) -> list:
    """Parse output produced by `read_log` into Commit objects."""
    commits = []
    for record in raw.split(RECORD_SEP):
        record = record.strip("\n")
        if not record:
            continue
        header, *numstat = record.split("\n")
        parts = header.split(FIELD_SEP)
        if len(parts) < 5:
            continue
        sha, author, email, date, subject = parts[0], parts[1], parts[2], parts[3], parts[4]
        changes = []
        for line in numstat:
            cols = line.split("\t")
            if len(cols) != 3:
                continue
            added, deleted, path = cols
            # Binary files are reported as "-"
            changes.append(
                FileChange(
                    path=path,
                    added=int(added) if added.isdigit() else 0,
                    deleted=int(deleted) if deleted.isdigit() else 0,
                )
            )
        commits.append(
            Commit(sha, author, email, datetime.fromisoformat(date), subject, changes)
        )
    return commits


def contributors(commits: Iterable[Commit]) -> list:
    """Return [(author, commit_count, lines_changed)] sorted by commits."""
    count: Counter = Counter()
    lines: Counter = Counter()
    for c in commits:
        count[c.author] += 1
        lines[c.author] += c.lines_changed
    return [(a, n, lines[a]) for a, n in count.most_common()]


def bus_factor(commits: Iterable[Commit], threshold: float = 0.5) -> int:
    """Smallest number of authors who together account for > threshold of commits.

    A low number means the project's knowledge is concentrated in few people.
    """
    ranked = contributors(commits)
    total = sum(n for _, n, _ in ranked)
    if total == 0:
        return 0
    running = 0
    for i, (_, n, _) in enumerate(ranked, start=1):
        running += n
        if running / total > threshold:
            return i
    return len(ranked)


def hotspots(commits: Iterable[Commit], top: int = 10) -> list:
    """Files that change most often: [(path, commits_touching, lines_changed)]."""
    touches: Counter = Counter()
    churn: defaultdict = defaultdict(int)
    for c in commits:
        for ch in c.changes:
            touches[ch.path] += 1
            churn[ch.path] += ch.added + ch.deleted
    ranked = sorted(touches, key=lambda p: (touches[p], churn[p]), reverse=True)
    return [(p, touches[p], churn[p]) for p in ranked[:top]]


def heatmap(commits: Iterable[Commit]) -> list:
    """7x24 grid of commit counts indexed [weekday (Mon=0)][hour]."""
    grid = [[0] * 24 for _ in range(7)]
    for c in commits:
        grid[c.date.weekday()][c.date.hour] += 1
    return grid


def summary(commits: list) -> dict:
    """High-level numbers for a list of commits."""
    if not commits:
        return {"commits": 0, "authors": 0, "first": None, "last": None,
                "lines_added": 0, "lines_deleted": 0, "bus_factor": 0}
    dates = [c.date for c in commits]
    return {
        "commits": len(commits),
        "authors": len({c.author for c in commits}),
        "first": min(dates).date().isoformat(),
        "last": max(dates).date().isoformat(),
        "lines_added": sum(ch.added for c in commits for ch in c.changes),
        "lines_deleted": sum(ch.deleted for c in commits for ch in c.changes),
        "bus_factor": bus_factor(commits),
    }
