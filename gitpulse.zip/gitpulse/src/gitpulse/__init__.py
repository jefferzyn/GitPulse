"""GitPulse: analyze a git repository's history."""

__version__ = "0.1.0"
