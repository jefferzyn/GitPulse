from gitpulse.cli import main

raise SystemExit(main())
